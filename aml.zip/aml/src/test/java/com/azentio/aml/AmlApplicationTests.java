package com.azentio.aml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
